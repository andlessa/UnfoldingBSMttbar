smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 5e-06,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : -1,
    'model' : '/home/vinicius/EFT_ToyModel/processFolders/VLF/pp2psiTpsiTbar/Cards/param_card.dat',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../processFolders/VLF_SLHAs/Scalar_825_650.slha',
    'database version' : '3.1.1',
    'smodels version' : '3.1.1'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 97.165,
        'upper limit (fb)' : 34.1,
        'expected upper limit (fb)' : 51.6,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t-,MET),(t+,MET)'],
        'Mass (GeV)' : [
            ('psit~', 825.0),
            ('psit', 825.0),
            ('~sdm', 650.0)
        ],
        'AnalysisID' : 'CMS-SUS-20-002',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 2.849413,
        'r_expected' : 1.883043,
        'Width (GeV)' : [
            ('psit~', 0.2408996),
            ('psit', 0.2408996),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 97.165,
        'upper limit (fb)' : 42.8509,
        'expected upper limit (fb)' : 82.5121,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 825.0),
            ('psit', 825.0),
            ('~sdm', 650.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-006',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 2.267514,
        'r_expected' : 1.177585,
        'Width (GeV)' : [
            ('psit~', 0.2408996),
            ('psit', 0.2408996),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 97.165,
        'upper limit (fb)' : 60.4236,
        'expected upper limit (fb)' : 69.2189,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 825.0),
            ('psit', 825.0),
            ('~sdm', 650.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-010',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.608064,
        'r_expected' : 1.403735,
        'Width (GeV)' : [
            ('psit~', 0.2408996),
            ('psit', 0.2408996),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 97.165,
        'upper limit (fb)' : 94.811,
        'expected upper limit (fb)' : 94.0104,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 825.0),
            ('psit', 825.0),
            ('~sdm', 650.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-009',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.024828,
        'r_expected' : 1.033556,
        'Width (GeV)' : [
            ('psit~', 0.2408996),
            ('psit', 0.2408996),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.775987,
        'upper limit (fb)' : 0.9158571,
        'expected upper limit (fb)' : 1.482515,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 825.0),
            ('psit', 825.0),
            ('~sdm', 650.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-050-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.8472796,
        'r_expected' : 0.523426,
        'Width (GeV)' : [
            ('psit~', 0.2408996),
            ('psit', 0.2408996),
            ('~sdm', 'stable')
        ],
        'nll' : 127.4346,
        'nll_min' : 125.2897,
        'nll_SM' : 125.2897
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 97.165,
        'upper limit (fb)' : 243.54,
        'expected upper limit (fb)' : 182.53,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 825.0),
            ('psit', 825.0),
            ('~sdm', 650.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-050',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'upperLimit',
        'r' : 0.3989694,
        'r_expected' : 0.5323235,
        'Width (GeV)' : [
            ('psit~', 0.2408996),
            ('psit', 0.2408996),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 97.165,
        'upper limit (fb)' : 327.805,
        'expected upper limit (fb)' : 301.015,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 825.0),
            ('psit', 825.0),
            ('~sdm', 650.0)
        ],
        'AnalysisID' : 'CMS-SUS-17-010',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'upperLimit',
        'r' : 0.296411,
        'r_expected' : 0.3227912,
        'Width (GeV)' : [
            ('psit~', 0.2408996),
            ('psit', 0.2408996),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2278879,
        'upper limit (fb)' : 0.887,
        'expected upper limit (fb)' : 0.704,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 825.0),
            ('psit', 825.0),
            ('~sdm', 650.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR12_Njet5_Nb1_HT750_MHT750',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.2569198,
        'r_expected' : 0.3237044,
        'Width (GeV)' : [
            ('psit~', 0.2408996),
            ('psit', 0.2408996),
            ('~sdm', 'stable')
        ],
        'nll' : 6.067216,
        'nll_min' : 6.04734,
        'nll_SM' : 6.166793
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 97.165,
        'upper limit (fb)' : 390.142,
        'expected upper limit (fb)' : 252.549,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 825.0),
            ('psit', 825.0),
            ('~sdm', 650.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-011',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.2490503,
        'r_expected' : 0.3847372,
        'Width (GeV)' : [
            ('psit~', 0.2408996),
            ('psit', 0.2408996),
            ('~sdm', 'stable')
        ]
    }
],
'Total xsec for missing topologies (fb)' : 0.0,
'missing topologies' : [],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.0,
'missing topologies with prompt decays' : [],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}