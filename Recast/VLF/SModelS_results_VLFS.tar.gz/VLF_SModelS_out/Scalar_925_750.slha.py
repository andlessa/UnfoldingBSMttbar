smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 5e-06,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : -1,
    'model' : '/home/vinicius/EFT_ToyModel/processFolders/VLF/pp2psiTpsiTbar/Cards/param_card.dat',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../processFolders/VLF_SLHAs/Scalar_925_750.slha',
    'database version' : '3.1.1',
    'smodels version' : '3.1.1'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 45.672,
        'upper limit (fb)' : 26.6,
        'expected upper limit (fb)' : 40.7,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t-,MET),(t+,MET)'],
        'Mass (GeV)' : [
            ('psit~', 925.0),
            ('psit', 925.0),
            ('~sdm', 750.0)
        ],
        'AnalysisID' : 'CMS-SUS-20-002',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.716992,
        'r_expected' : 1.122162,
        'Width (GeV)' : [
            ('psit~', 0.2180341),
            ('psit', 0.2180341),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 45.672,
        'upper limit (fb)' : 40.5459,
        'expected upper limit (fb)' : 72.6725,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 925.0),
            ('psit', 925.0),
            ('~sdm', 750.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-006',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.126427,
        'r_expected' : 0.6284633,
        'Width (GeV)' : [
            ('psit~', 0.2180341),
            ('psit', 0.2180341),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 45.672,
        'upper limit (fb)' : 63.8993,
        'expected upper limit (fb)' : 68.1057,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 925.0),
            ('psit', 925.0),
            ('~sdm', 750.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-009',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.7147496,
        'r_expected' : 0.6706047,
        'Width (GeV)' : [
            ('psit~', 0.2180341),
            ('psit', 0.2180341),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.142582,
        'upper limit (fb)' : 0.887,
        'expected upper limit (fb)' : 0.704,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 925.0),
            ('psit', 925.0),
            ('~sdm', 750.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR12_Njet5_Nb1_HT750_MHT750',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.1607464,
        'r_expected' : 0.2025313,
        'Width (GeV)' : [
            ('psit~', 0.2180341),
            ('psit', 0.2180341),
            ('~sdm', 'stable')
        ],
        'nll' : 6.048975,
        'nll_min' : 6.04734,
        'nll_SM' : 6.166793
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 45.672,
        'upper limit (fb)' : 731.1,
        'expected upper limit (fb)' : 272.939,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 925.0),
            ('psit', 925.0),
            ('~sdm', 750.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-011',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.06247025,
        'r_expected' : 0.1673341,
        'Width (GeV)' : [
            ('psit~', 0.2180341),
            ('psit', 0.2180341),
            ('~sdm', 'stable')
        ]
    }
],
'Total xsec for missing topologies (fb)' : 0.0,
'missing topologies' : [],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.0,
'missing topologies with prompt decays' : [],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}