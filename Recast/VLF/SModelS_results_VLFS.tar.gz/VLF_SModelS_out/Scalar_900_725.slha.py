smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 5e-06,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : -1,
    'model' : '/home/vinicius/EFT_ToyModel/processFolders/VLF/pp2psiTpsiTbar/Cards/param_card.dat',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../processFolders/VLF_SLHAs/Scalar_900_725.slha',
    'database version' : '3.1.1',
    'smodels version' : '3.1.1'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 54.728,
        'upper limit (fb)' : 27.8,
        'expected upper limit (fb)' : 41.8,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t-,MET),(t+,MET)'],
        'Mass (GeV)' : [
            ('psit~', 900.0),
            ('psit', 900.0),
            ('~sdm', 725.0)
        ],
        'AnalysisID' : 'CMS-SUS-20-002',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.968633,
        'r_expected' : 1.309282,
        'Width (GeV)' : [
            ('psit~', 0.2233458),
            ('psit', 0.2233458),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 54.728,
        'upper limit (fb)' : 40.612,
        'expected upper limit (fb)' : 52.4309,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 900.0),
            ('psit', 900.0),
            ('~sdm', 725.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-010',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.347582,
        'r_expected' : 1.043812,
        'Width (GeV)' : [
            ('psit~', 0.2233458),
            ('psit', 0.2233458),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 54.728,
        'upper limit (fb)' : 44.88,
        'expected upper limit (fb)' : 79.1747,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 900.0),
            ('psit', 900.0),
            ('~sdm', 725.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-006',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.21943,
        'r_expected' : 0.6912309,
        'Width (GeV)' : [
            ('psit~', 0.2233458),
            ('psit', 0.2233458),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 54.728,
        'upper limit (fb)' : 64.5394,
        'expected upper limit (fb)' : 69.6566,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 900.0),
            ('psit', 900.0),
            ('~sdm', 725.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-009',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.8479781,
        'r_expected' : 0.7856829,
        'Width (GeV)' : [
            ('psit~', 0.2233458),
            ('psit', 0.2233458),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1602299,
        'upper limit (fb)' : 0.887,
        'expected upper limit (fb)' : 0.704,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 900.0),
            ('psit', 900.0),
            ('~sdm', 725.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR12_Njet5_Nb1_HT750_MHT750',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.1806425,
        'r_expected' : 0.2275993,
        'Width (GeV)' : [
            ('psit~', 0.2233458),
            ('psit', 0.2233458),
            ('~sdm', 'stable')
        ],
        'nll' : 6.047348,
        'nll_min' : 6.04734,
        'nll_SM' : 6.166793
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 54.728,
        'upper limit (fb)' : 1000.44,
        'expected upper limit (fb)' : 333.532,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 900.0),
            ('psit', 900.0),
            ('~sdm', 725.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-011',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.05470393,
        'r_expected' : 0.1640862,
        'Width (GeV)' : [
            ('psit~', 0.2233458),
            ('psit', 0.2233458),
            ('~sdm', 'stable')
        ]
    }
],
'Total xsec for missing topologies (fb)' : 0.0,
'missing topologies' : [],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.0,
'missing topologies with prompt decays' : [],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}