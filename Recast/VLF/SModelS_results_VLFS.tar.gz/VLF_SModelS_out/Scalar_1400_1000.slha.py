smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 5e-06,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : -1,
    'model' : '/home/vinicius/EFT_ToyModel/processFolders/VLF/pp2psiTpsiTbar/Cards/param_card.dat',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../processFolders/VLF_SLHAs/Scalar_1400_1000.slha',
    'database version' : '3.1.1',
    'smodels version' : '3.1.1'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.1361,
        'upper limit (fb)' : 3.01,
        'expected upper limit (fb)' : 3.77,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t-,MET),(t+,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1400.0),
            ('psit', 1400.0),
            ('~sdm', 1000.0)
        ],
        'AnalysisID' : 'CMS-SUS-20-002',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.7096678,
        'r_expected' : 0.5666048,
        'Width (GeV)' : [
            ('psit~', 3.099626),
            ('psit', 3.099626),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.1361,
        'upper limit (fb)' : 5.58503,
        'expected upper limit (fb)' : 6.42572,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1400.0),
            ('psit', 1400.0),
            ('~sdm', 1000.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-009',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.3824688,
        'r_expected' : 0.3324297,
        'Width (GeV)' : [
            ('psit~', 3.099626),
            ('psit', 3.099626),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4334673,
        'upper limit (fb)' : 1.195743,
        'expected upper limit (fb)' : 2.302566,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1400.0),
            ('psit', 1400.0),
            ('~sdm', 1000.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-006-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.3625086,
        'r_expected' : 0.188254,
        'Width (GeV)' : [
            ('psit~', 3.099626),
            ('psit', 3.099626),
            ('~sdm', 'stable')
        ],
        'nll' : 250.1782,
        'nll_min' : 249.5166,
        'nll_SM' : 249.5166
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.1361,
        'upper limit (fb)' : 6.06292,
        'expected upper limit (fb)' : 9.71585,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1400.0),
            ('psit', 1400.0),
            ('~sdm', 1000.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-006',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.352322,
        'r_expected' : 0.2198572,
        'Width (GeV)' : [
            ('psit~', 3.099626),
            ('psit', 3.099626),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.09169636,
        'upper limit (fb)' : 2.46,
        'expected upper limit (fb)' : 1.85,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1400.0),
            ('psit', 1400.0),
            ('~sdm', 1000.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR6_Njet2_Nb2_HT500_MHT500',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.03727495,
        'r_expected' : 0.0495656,
        'Width (GeV)' : [
            ('psit~', 3.099626),
            ('psit', 3.099626),
            ('~sdm', 'stable')
        ],
        'nll' : 7.99802,
        'nll_min' : 7.858107,
        'nll_SM' : 8.058678
    }
],
'Total xsec for missing topologies (fb)' : 0.0,
'missing topologies' : [],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.0,
'missing topologies with prompt decays' : [],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}