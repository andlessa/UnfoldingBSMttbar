smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 5e-06,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : -1,
    'model' : '/home/vinicius/EFT_ToyModel/processFolders/VLF/pp2psiTpsiTbar/Cards/param_card.dat',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../processFolders/VLF_SLHAs/Scalar_850_675.slha',
    'database version' : '3.1.1',
    'smodels version' : '3.1.1'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 80.009,
        'upper limit (fb)' : 26.8,
        'expected upper limit (fb)' : 42.4,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t-,MET),(t+,MET)'],
        'Mass (GeV)' : [
            ('psit~', 850.0),
            ('psit', 850.0),
            ('~sdm', 675.0)
        ],
        'AnalysisID' : 'CMS-SUS-20-002',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 2.98541,
        'r_expected' : 1.887005,
        'Width (GeV)' : [
            ('psit~', 0.2347595),
            ('psit', 0.2347595),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 80.009,
        'upper limit (fb)' : 45.1929,
        'expected upper limit (fb)' : 82.4692,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 850.0),
            ('psit', 850.0),
            ('~sdm', 675.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-006',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.770389,
        'r_expected' : 0.9701683,
        'Width (GeV)' : [
            ('psit~', 0.2347595),
            ('psit', 0.2347595),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 80.009,
        'upper limit (fb)' : 47.8788,
        'expected upper limit (fb)' : 62.0687,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 850.0),
            ('psit', 850.0),
            ('~sdm', 675.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-010',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.671074,
        'r_expected' : 1.289039,
        'Width (GeV)' : [
            ('psit~', 0.2347595),
            ('psit', 0.2347595),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 80.009,
        'upper limit (fb)' : 76.9303,
        'expected upper limit (fb)' : 81.0885,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 850.0),
            ('psit', 850.0),
            ('~sdm', 675.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-009',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.040019,
        'r_expected' : 0.9866874,
        'Width (GeV)' : [
            ('psit~', 0.2347595),
            ('psit', 0.2347595),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2031821,
        'upper limit (fb)' : 0.887,
        'expected upper limit (fb)' : 0.704,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 850.0),
            ('psit', 850.0),
            ('~sdm', 675.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR12_Njet5_Nb1_HT750_MHT750',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.2290666,
        'r_expected' : 0.2886109,
        'Width (GeV)' : [
            ('psit~', 0.2347595),
            ('psit', 0.2347595),
            ('~sdm', 'stable')
        ],
        'nll' : 6.055178,
        'nll_min' : 6.04734,
        'nll_SM' : 6.166793
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 80.009,
        'upper limit (fb)' : 533.026,
        'expected upper limit (fb)' : 342.69,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 850.0),
            ('psit', 850.0),
            ('~sdm', 675.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-011',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.1501034,
        'r_expected' : 0.2334734,
        'Width (GeV)' : [
            ('psit~', 0.2347595),
            ('psit', 0.2347595),
            ('~sdm', 'stable')
        ]
    }
],
'Total xsec for missing topologies (fb)' : 0.0,
'missing topologies' : [],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.0,
'missing topologies with prompt decays' : [],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}