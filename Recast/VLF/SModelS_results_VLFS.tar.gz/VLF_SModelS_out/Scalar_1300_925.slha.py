smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 5e-06,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : -1,
    'model' : '/home/vinicius/EFT_ToyModel/processFolders/VLF/pp2psiTpsiTbar/Cards/param_card.dat',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../processFolders/VLF_SLHAs/Scalar_1300_925.slha',
    'database version' : '3.1.1',
    'smodels version' : '3.1.1'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.8669,
        'upper limit (fb)' : 3.64,
        'expected upper limit (fb)' : 4.895,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t-,MET),(t+,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1300.0),
            ('psit', 1300.0),
            ('~sdm', 925.0)
        ],
        'AnalysisID' : 'CMS-SUS-20-002',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.062335,
        'r_expected' : 0.7899694,
        'Width (GeV)' : [
            ('psit~', 2.891568),
            ('psit', 2.891568),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.6800983,
        'upper limit (fb)' : 1.225678,
        'expected upper limit (fb)' : 2.41358,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1300.0),
            ('psit', 1300.0),
            ('~sdm', 925.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-006-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.5548752,
        'r_expected' : 0.2817799,
        'Width (GeV)' : [
            ('psit~', 2.891568),
            ('psit', 2.891568),
            ('~sdm', 'stable')
        ],
        'nll' : 250.6024,
        'nll_min' : 249.5166,
        'nll_SM' : 249.5166
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.8669,
        'upper limit (fb)' : 6.9746,
        'expected upper limit (fb)' : 11.7831,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1300.0),
            ('psit', 1300.0),
            ('~sdm', 925.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-006',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.5544261,
        'r_expected' : 0.3281734,
        'Width (GeV)' : [
            ('psit~', 2.891568),
            ('psit', 2.891568),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.8669,
        'upper limit (fb)' : 6.99911,
        'expected upper limit (fb)' : 7.72438,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1300.0),
            ('psit', 1300.0),
            ('~sdm', 925.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-009',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.5524845,
        'r_expected' : 0.5006098,
        'Width (GeV)' : [
            ('psit~', 2.891568),
            ('psit', 2.891568),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1466491,
        'upper limit (fb)' : 2.46,
        'expected upper limit (fb)' : 1.85,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1300.0),
            ('psit', 1300.0),
            ('~sdm', 925.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR6_Njet2_Nb2_HT500_MHT500',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.05961345,
        'r_expected' : 0.07926978,
        'Width (GeV)' : [
            ('psit~', 2.891568),
            ('psit', 2.891568),
            ('~sdm', 'stable')
        ],
        'nll' : 7.9669,
        'nll_min' : 7.858107,
        'nll_SM' : 8.058678
    }
],
'Total xsec for missing topologies (fb)' : 0.0,
'missing topologies' : [],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.0,
'missing topologies with prompt decays' : [],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}