smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 5e-06,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : -1,
    'model' : '/home/vinicius/EFT_ToyModel/processFolders/VLF/pp2psiTpsiTbar/Cards/param_card.dat',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../processFolders/VLF_SLHAs/Scalar_1350_900.slha',
    'database version' : '3.1.1',
    'smodels version' : '3.1.1'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.8646,
        'upper limit (fb)' : 2.15,
        'expected upper limit (fb)' : 2.72,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t-,MET),(t+,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1350.0),
            ('psit', 1350.0),
            ('~sdm', 900.0)
        ],
        'AnalysisID' : 'CMS-SUS-20-002',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.332372,
        'r_expected' : 1.053162,
        'Width (GeV)' : [
            ('psit~', 3.93033),
            ('psit', 3.93033),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.8646,
        'upper limit (fb)' : 3.93922,
        'expected upper limit (fb)' : 4.6522,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1350.0),
            ('psit', 1350.0),
            ('~sdm', 900.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-009',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.7271998,
        'r_expected' : 0.6157517,
        'Width (GeV)' : [
            ('psit~', 3.93033),
            ('psit', 3.93033),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.8646,
        'upper limit (fb)' : 4.59077,
        'expected upper limit (fb)' : 7.30403,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1350.0),
            ('psit', 1350.0),
            ('~sdm', 900.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-006',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.6239912,
        'r_expected' : 0.3921944,
        'Width (GeV)' : [
            ('psit~', 3.93033),
            ('psit', 3.93033),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.6689399,
        'upper limit (fb)' : 1.098943,
        'expected upper limit (fb)' : 2.007114,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1350.0),
            ('psit', 1350.0),
            ('~sdm', 900.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-006-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.6087121,
        'r_expected' : 0.3332844,
        'Width (GeV)' : [
            ('psit~', 3.93033),
            ('psit', 3.93033),
            ('~sdm', 'stable')
        ],
        'nll' : 250.6927,
        'nll_min' : 249.5166,
        'nll_SM' : 249.5166
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1887032,
        'upper limit (fb)' : 2.46,
        'expected upper limit (fb)' : 1.85,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1350.0),
            ('psit', 1350.0),
            ('~sdm', 900.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR6_Njet2_Nb2_HT500_MHT500',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.07670863,
        'r_expected' : 0.1020017,
        'Width (GeV)' : [
            ('psit~', 3.93033),
            ('psit', 3.93033),
            ('~sdm', 'stable')
        ],
        'nll' : 7.94573,
        'nll_min' : 7.858107,
        'nll_SM' : 8.058678
    }
],
'Total xsec for missing topologies (fb)' : 0.0,
'missing topologies' : [],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.0,
'missing topologies with prompt decays' : [],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}