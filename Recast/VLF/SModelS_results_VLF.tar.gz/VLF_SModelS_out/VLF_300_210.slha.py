smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 5e-06,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : -1,
    'model' : '/home/vinicius/EFT_ToyModel/processFolders/VLF/pp2psiTpsiTbar/Cards/param_card.dat',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../processFolders/VLF_SLHAs/VLF_300_210.slha',
    'database version' : '3.1.1',
    'smodels version' : '3.1.1'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 109.1333,
        'upper limit (fb)' : 1.81592,
        'expected upper limit (fb)' : 2.723483,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W,b,MET),(W,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-006-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 60.09811,
        'r_expected' : 40.07124,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ],
        'nll' : 1498.665,
        'nll_min' : 249.5166,
        'nll_SM' : 249.5166
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 31197.0,
        'upper limit (fb)' : 1520.2,
        'expected upper limit (fb)' : 2668.86,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W,b,MET),(W,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'upperLimit',
        'r' : 20.52164,
        'r_expected' : 11.68926,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 31197.0,
        'upper limit (fb)' : 1705.38,
        'expected upper limit (fb)' : 1194.69,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W-,b,MET),(W+,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'CMS-SUS-20-002',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 18.29328,
        'r_expected' : 26.11305,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 31197.0,
        'upper limit (fb)' : 1729.25,
        'expected upper limit (fb)' : 2462.67,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W,b,MET),(W,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'CMS-SUS-17-010',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'upperLimit',
        'r' : 18.04077,
        'r_expected' : 12.66796,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 31197.0,
        'upper limit (fb)' : 1920.99,
        'expected upper limit (fb)' : 1552.37,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W,b,MET),(W,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-009',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 16.24006,
        'r_expected' : 20.09637,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 50.2802,
        'upper limit (fb)' : 3.17,
        'expected upper limit (fb)' : 5.0,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W,b,MET),(W,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR11_Njet7_Nb1_HT300_MHT300',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 15.86126,
        'r_expected' : 10.05604,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ],
        'nll' : 247.1034,
        'nll_min' : 10.04328,
        'nll_SM' : 10.04328
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 31197.0,
        'upper limit (fb)' : 2160.94,
        'expected upper limit (fb)' : 2540.14,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W,b,MET),(W,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-006',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 14.43677,
        'r_expected' : 12.28161,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 31197.0,
        'upper limit (fb)' : 3680.0,
        'expected upper limit (fb)' : None,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W,b,MET),(W,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-17',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'upperLimit',
        'r' : 8.477446,
        'r_expected' : None,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 31197.0,
        'upper limit (fb)' : 3805.1,
        'expected upper limit (fb)' : None,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W,b,MET),(W,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-15',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'upperLimit',
        'r' : 8.198733,
        'r_expected' : None,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.5907558,
        'upper limit (fb)' : 0.0799,
        'expected upper limit (fb)' : 0.0799,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W,b,MET),(W,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-08',
        'DataSetID' : 'SR4la',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 7.393689,
        'r_expected' : 7.393689,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ],
        'nll' : 52.528,
        'nll_min' : 4.309436,
        'nll_SM' : 4.309436
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 31197.0,
        'upper limit (fb)' : 4225.1,
        'expected upper limit (fb)' : 2691.58,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W,b,MET),(W,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-010',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 7.383731,
        'r_expected' : 11.59059,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 31197.0,
        'upper limit (fb)' : 4954.0,
        'expected upper limit (fb)' : None,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W,b,MET),(W,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-16',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'upperLimit',
        'r' : 6.297335,
        'r_expected' : None,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.779829,
        'upper limit (fb)' : 0.861,
        'expected upper limit (fb)' : 0.917,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W,b,MET),(W,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-16',
        'DataSetID' : 'bWN',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.0,
        'dataType' : 'efficiencyMap',
        'r' : 4.390045,
        'r_expected' : 4.12195,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ],
        'nll' : 34.41988,
        'nll_min' : 6.735316,
        'nll_SM' : 6.735316
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 31197.0,
        'upper limit (fb)' : 7690.88,
        'expected upper limit (fb)' : 8547.46,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W,b,MET),(W,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-051',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'upperLimit',
        'r' : 4.056363,
        'r_expected' : 3.649856,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 31197.0,
        'upper limit (fb)' : 13703.8,
        'expected upper limit (fb)' : 10787.4,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W,b,MET),(W,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-009',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 2.3,
        'dataType' : 'upperLimit',
        'r' : 2.276522,
        'r_expected' : 2.891985,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 31197.0,
        'upper limit (fb)' : 38986.7,
        'expected upper limit (fb)' : 33877.0,
        'TxNames' : ['T2ttoff'],
        'FinalStates' : ['PV > (W,b,MET),(W,b,MET)'],
        'Mass (GeV)' : [
            ('psit~', 300.0),
            ('psit', 300.0),
            ('~sdm', 210.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-011',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.800196,
        'r_expected' : 0.9208903,
        'Width (GeV)' : [
            ('psit~', 4.4377e-07),
            ('psit', 4.4377e-07),
            ('~sdm', 'stable')
        ]
    }
],
'Total xsec for missing topologies (fb)' : 0.0,
'missing topologies' : [],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.0,
'missing topologies with prompt decays' : [],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}