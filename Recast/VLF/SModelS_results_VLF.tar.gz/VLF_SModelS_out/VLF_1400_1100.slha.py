smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 5e-06,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : -1,
    'model' : '/home/vinicius/EFT_ToyModel/processFolders/VLF/pp2psiTpsiTbar/Cards/param_card.dat',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../processFolders/VLF_Slhas/VLF_1400_1100.slha',
    'database version' : '3.1.1',
    'smodels version' : '3.1.1'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.1361,
        'upper limit (fb)' : 6.16,
        'expected upper limit (fb)' : 8.13,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t-,MET),(t+,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1400.0),
            ('psit', 1400.0),
            ('~sdm', 1100.0)
        ],
        'AnalysisID' : 'CMS-SUS-20-002',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.3467695,
        'r_expected' : 0.2627429,
        'Width (GeV)' : [
            ('psit~', 1.730353),
            ('psit', 1.730353),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2445068,
        'upper limit (fb)' : 1.153526,
        'expected upper limit (fb)' : 2.351201,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1400.0),
            ('psit', 1400.0),
            ('~sdm', 1100.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-006-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.2119647,
        'r_expected' : 0.1039923,
        'Width (GeV)' : [
            ('psit~', 1.730353),
            ('psit', 1.730353),
            ('~sdm', 'stable')
        ],
        'nll' : 249.8969,
        'nll_min' : 249.5166,
        'nll_SM' : 249.5166
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.1361,
        'upper limit (fb)' : 11.3095,
        'expected upper limit (fb)' : 16.8939,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1400.0),
            ('psit', 1400.0),
            ('~sdm', 1100.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-006',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.1888766,
        'r_expected' : 0.1264421,
        'Width (GeV)' : [
            ('psit~', 1.730353),
            ('psit', 1.730353),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.1361,
        'upper limit (fb)' : 13.1437,
        'expected upper limit (fb)' : 12.8506,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1400.0),
            ('psit', 1400.0),
            ('~sdm', 1100.0)
        ],
        'AnalysisID' : 'CMS-SUS-19-009',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.1625189,
        'r_expected' : 0.1662257,
        'Width (GeV)' : [
            ('psit~', 1.730353),
            ('psit', 1.730353),
            ('~sdm', 'stable')
        ]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01994353,
        'upper limit (fb)' : 0.887,
        'expected upper limit (fb)' : 0.704,
        'TxNames' : ['T2tt'],
        'FinalStates' : ['PV > (t,MET),(t,MET)'],
        'Mass (GeV)' : [
            ('psit~', 1400.0),
            ('psit', 1400.0),
            ('~sdm', 1100.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR12_Njet5_Nb1_HT750_MHT750',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.02248425,
        'r_expected' : 0.02832887,
        'Width (GeV)' : [
            ('psit~', 1.730353),
            ('psit', 1.730353),
            ('~sdm', 'stable')
        ],
        'nll' : 6.13902,
        'nll_min' : 6.04734,
        'nll_SM' : 6.166793
    }
],
'Total xsec for missing topologies (fb)' : 0.0,
'missing topologies' : [],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.0,
'missing topologies with prompt decays' : [],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}